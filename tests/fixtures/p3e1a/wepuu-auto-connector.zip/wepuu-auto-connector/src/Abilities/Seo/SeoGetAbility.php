<?php
/**
 * Phase 1.6.1 provider-neutral SEO Get Ability.
 *
 * @package WPAutoConnector
 */

namespace WPAuto\Connector\Abilities\Seo;

use WPAuto\Connector\Seo\SeoContract;
use WPAuto\Connector\Seo\SeoReadService;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Registers the fixed read-only SEO Get contract. */
final class SeoGetAbility {
	public const NAME = 'wp-auto/seo-get';

	/** Register the Ability hook. */
	public function register(): void {
		add_action( 'wp_abilities_api_init', array( $this, 'register_ability' ) );
	}

	/** Register the Ability with WordPress Core. */
	public function register_ability(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			self::NAME,
			array(
				'label'               => __( 'WP-Auto SEO Get', 'wepuu-auto-connector' ),
				'description'         => __( 'Returns explicit SEO overrides for one authorized WordPress Post or Page.', 'wepuu-auto-connector' ),
				'category'            => SeoAbilityCategory::SLUG,
				'input_schema'        => SeoContract::get_input_schema(),
				'output_schema'       => SeoContract::output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	/**
	 * Execute the provider-neutral SEO read.
	 *
	 * @param mixed $input Validated Ability input.
	 */
	public function execute( $input ) {
		return ( new SeoReadService() )->get( $input );
	}

	/** Enforce Core and provider read permissions at Ability entry. */
	public function check_permission(): bool {
		return ( new SeoReadService() )->can_read();
	}
}
